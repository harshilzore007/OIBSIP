import { WebSocketServer, WebSocket } from 'ws';
import type { Server } from 'http';
import jwt from 'jsonwebtoken';
import { db } from './db';
import type { Order, OrderStatus } from '../src/types';

const JWT_SECRET = process.env.JWT_SECRET || 'pizza_craft_super_secret_jwt_key_2026';

let wss: WebSocketServer | null = null;

export interface RealtimeMessage {
  type: string;
  [key: string]: any;
}

export function setupWebSocketServer(httpServer: Server): WebSocketServer {
  wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    // Send initial snapshot on connect
    const initialItems = db.inventory.find();
    const initialGrouped = {
      bases: initialItems.filter((i) => i.category === 'bases'),
      sauces: initialItems.filter((i) => i.category === 'sauces'),
      cheeses: initialItems.filter((i) => i.category === 'cheeses'),
      vegetables: initialItems.filter((i) => i.category === 'vegetables'),
    };
    const lowStockCount = initialItems.filter((i) => i.stock < i.threshold).length;

    ws.send(
      JSON.stringify({
        type: 'connected',
        message: 'Connected to PizzaCraft Realtime Live Stream',
        timestamp: new Date().toISOString(),
        inventory: {
          items: initialItems,
          grouped: initialGrouped,
          lowStockCount,
        },
      })
    );

    ws.on('message', (raw: string) => {
      try {
        const data = JSON.parse(raw.toString()) as RealtimeMessage;
        handleIncomingMessage(ws, data);
      } catch (err) {
        console.error('Error parsing WS message:', err);
      }
    });

    ws.on('error', (err) => {
      console.warn('WS Client Error:', err.message);
    });
  });

  return wss;
}

function handleIncomingMessage(ws: WebSocket, data: RealtimeMessage) {
  if (data.type === 'ping') {
    ws.send(JSON.stringify({ type: 'pong', time: Date.now() }));
    return;
  }

  // Helper to verify admin token from websocket payload
  const verifyIsAdmin = (token?: string): boolean => {
    if (!token) return false;
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      return decoded && decoded.role === 'admin';
    } catch {
      return false;
    }
  };

  // Step order forward in real-time - STRICTLY RESTRICTED TO AUTHORIZED KITCHEN ADMIN
  if (data.type === 'order:simulate_step' && data.orderId) {
    if (!verifyIsAdmin(data.token)) {
      ws.send(
        JSON.stringify({
          type: 'error',
          message: 'Access Denied: Customer cannot update order status once placed. Only authorized kitchen staff can update orders.',
        })
      );
      return;
    }

    const order = db.orders.findById(data.orderId);
    if (!order) return;

    const sequence: OrderStatus[] = [
      'order_received',
      'in_kitchen',
      'sent_to_delivery',
      'delivered',
    ];
    const currentIndex = sequence.indexOf(order.status);
    if (currentIndex >= 0 && currentIndex < sequence.length - 1) {
      const nextStatus = sequence[currentIndex + 1];
      const notes: Record<OrderStatus, string> = {
        order_received: 'Order confirmed and scheduled.',
        in_kitchen: 'Artisan Chef has stretched the dough and transferred to the 800°F stone hearth oven.',
        sent_to_delivery: 'Dispatched in insulated thermal carrier with delivery courier.',
        delivered: 'Delivered to your doorstep. Buon appetito!',
        cancelled: 'Order was cancelled.',
      };
      const updated = db.orders.updateStatus(order.id, nextStatus, notes[nextStatus]);
      if (updated) {
        broadcastOrderStatusUpdated(updated);
      }
    }
  }

  // Inventory quick restock / adjust via realtime - ADMIN ONLY
  if (data.type === 'inventory:quick_restock' && data.itemId) {
    if (!verifyIsAdmin(data.token)) {
      ws.send(
        JSON.stringify({
          type: 'error',
          message: 'Access Denied: Inventory adjustments require administrative privileges.',
        })
      );
      return;
    }

    const item = db.inventory.findById(data.itemId);
    if (item) {
      const addAmount = typeof data.amount === 'number' ? data.amount : 25;
      const updated = db.inventory.update(item.id, { stock: item.stock + addAmount });
      if (updated) {
        broadcastInventoryChanged();
      }
    }
  }

  // Real-Time Courier Dispatch Chat
  if (data.type === 'courier:send_message' && data.orderId && data.message) {
    const order = db.orders.findById(data.orderId);
    if (order) {
      const chatMsg = {
        id: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        orderId: data.orderId,
        sender: data.sender || 'customer',
        senderName: data.senderName || 'Customer',
        message: data.message,
        timestamp: new Date().toISOString(),
      };

      // Broadcast customer message to all listeners for this order
      broadcast({
        type: 'courier:message_received',
        chat: chatMsg,
      });

      // If customer sent message, simulate courier real-time reply after 1.2s
      if (data.sender === 'customer') {
        setTimeout(() => {
          const courierResponses = [
            `Ciao! Courier Marco here—I'm currently at ${Math.floor(1 + Math.random() * 5)} km away, pizza is steaming hot in the 165°F thermal bag! 🛵🍕`,
            `Received loud and clear! Passing through the main avenue now, ETA is about 4-6 minutes!`,
            `Copy that! I will ring the doorbell gently when I arrive at your building entrance!`,
            `Perfetto! Arriving very soon with your fresh artisan pizza!`,
          ];
          const courierReply = {
            id: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            orderId: data.orderId,
            sender: 'courier',
            senderName: 'Courier Marco Rossi (Vespa #12)',
            message: courierResponses[Math.floor(Math.random() * courierResponses.length)],
            timestamp: new Date().toISOString(),
          };

          broadcast({
            type: 'courier:message_received',
            chat: courierReply,
          });
        }, 1200);
      }
    }
  }

  // Request Pizzeria live pulse
  if (data.type === 'pizzeria:request_pulse') {
    ws.send(JSON.stringify(getLivePizzeriaPulse()));
  }
}

export function getLivePizzeriaPulse() {
  const orders = db.orders.find();
  const activeOrders = orders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled');
  const inKitchenCount = orders.filter((o) => o.status === 'in_kitchen').length;
  const onDeliveryCount = orders.filter((o) => o.status === 'sent_to_delivery').length;
  const deliveredToday = orders.filter((o) => o.status === 'delivered').length;

  return {
    type: 'pizzeria:pulse',
    activeOrdersCount: activeOrders.length,
    bakingCount: Math.max(1, inKitchenCount * 2 + 3), // active artisan hearth pies
    onDeliveryCount,
    deliveredTodayCount: deliveredToday + 28, // base simulated count + real
    hearthTempFahrenheit: 805 + Math.floor(Math.random() * 15),
    averagePrepTimeMins: Math.min(35, 18 + activeOrders.length * 2),
    timestamp: new Date().toISOString(),
  };
}

export function broadcast(payload: RealtimeMessage) {
  if (!wss) return;
  const messageStr = JSON.stringify(payload);
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(messageStr);
    }
  }
}

export function broadcastOrderCreated(order: Order) {
  broadcast({
    type: 'order:created',
    event: 'newOrder',
    order,
    timestamp: new Date().toISOString(),
  });
  // Also inventory decremented, broadcast refreshed inventory
  broadcastInventoryChanged();
}

export function broadcastOrderStatusUpdated(order: Order) {
  broadcast({
    type: 'order:status_updated',
    event: 'orderStatusUpdated',
    order,
    timestamp: new Date().toISOString(),
  });
}

export function broadcastInventoryChanged() {
  const items = db.inventory.find();
  const grouped = {
    bases: items.filter((i) => i.category === 'bases'),
    sauces: items.filter((i) => i.category === 'sauces'),
    cheeses: items.filter((i) => i.category === 'cheeses'),
    vegetables: items.filter((i) => i.category === 'vegetables'),
  };
  const lowStockCount = items.filter((i) => i.stock < i.threshold).length;

  broadcast({
    type: 'inventory:updated',
    items,
    grouped,
    lowStockCount,
    timestamp: new Date().toISOString(),
  });
}
