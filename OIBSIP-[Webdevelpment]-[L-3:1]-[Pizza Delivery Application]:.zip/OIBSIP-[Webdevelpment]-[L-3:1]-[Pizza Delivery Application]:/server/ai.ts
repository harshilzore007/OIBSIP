import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import { db } from './db';
import type { InventoryItem, Order } from '../src/types';

dotenv.config();

// Initialize server-side Gemini client per official skill guidelines
export const geminiClient = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export const GEMINI_MODEL = 'gemini-3.8-flash';

// Helper to get active inventory context for the AI
export function getInventorySummary() {
  const items = db.inventory.find();
  return {
    bases: items.filter((i) => i.category === 'bases').map((i) => ({ id: i.id, name: i.name, desc: i.description, price: i.price, stock: i.stock })),
    sauces: items.filter((i) => i.category === 'sauces').map((i) => ({ id: i.id, name: i.name, desc: i.description, price: i.price, stock: i.stock })),
    cheeses: items.filter((i) => i.category === 'cheeses').map((i) => ({ id: i.id, name: i.name, desc: i.description, price: i.price, stock: i.stock })),
    vegetables: items.filter((i) => i.category === 'vegetables').map((i) => ({ id: i.id, name: i.name, desc: i.description, price: i.price, stock: i.stock })),
  };
}

// 1. AI Pizza Crafter: Generates custom pizza from natural prompt
export async function aiCraftPizza(userPrompt: string) {
  const inv = getInventorySummary();

  const systemInstruction = `
You are Maestro Luigi, executive master pizzaiolo of PizzaCraft Artisan Pizzeria in Naples.
Your job is to craft a custom gourmet pizza configuration based on the customer's craving or mood.
You MUST choose ONLY from the available ingredients list provided in the prompt:
Bases: ${JSON.stringify(inv.bases.map((b) => ({ id: b.id, name: b.name })))}
Sauces: ${JSON.stringify(inv.sauces.map((s) => ({ id: s.id, name: s.name })))}
Cheeses: ${JSON.stringify(inv.cheeses.map((c) => ({ id: c.id, name: c.name })))}
Vegetables: ${JSON.stringify(inv.vegetables.map((v) => ({ id: v.id, name: v.name })))}

Select exactly ONE baseId, ONE sauceId, ONE cheeseId, and 1 to 4 vegetableIds that create maximum culinary synergy.
Explain the flavor notes passionately like an authentic Italian pizzaiolo.
Return strictly valid JSON matching the schema.
`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await geminiClient.models.generateContent({
        model: GEMINI_MODEL,
        contents: `Customer craving: "${userPrompt}"`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: 'Artisan Italian pizza name' },
              tagline: { type: Type.STRING, description: 'Catchy 1-line culinary tagline' },
              description: { type: Type.STRING, description: '2-sentence mouth-watering description' },
              baseId: { type: Type.STRING, description: 'Selected base id' },
              sauceId: { type: Type.STRING, description: 'Selected sauce id' },
              cheeseId: { type: Type.STRING, description: 'Selected cheese id' },
              vegetableIds: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Array of 1 to 4 vegetable ids',
              },
              flavorHarmonyScore: { type: Type.INTEGER, description: 'Harmony percentage 80-100' },
              tastingNotes: { type: Type.STRING, description: 'Sommelier tasting notes' },
              beveragePairing: { type: Type.STRING, description: 'Recommended wine or craft drink' },
              estimatedCalories: { type: Type.INTEGER, description: 'Estimated calories per slice (180-320)' },
              macros: {
                type: Type.OBJECT,
                properties: {
                  proteinGrams: { type: Type.INTEGER },
                  carbsGrams: { type: Type.INTEGER },
                  fatsGrams: { type: Type.INTEGER },
                },
                required: ['proteinGrams', 'carbsGrams', 'fatsGrams'],
              },
            },
            required: [
              'name',
              'tagline',
              'description',
              'baseId',
              'sauceId',
              'cheeseId',
              'vegetableIds',
              'flavorHarmonyScore',
              'tastingNotes',
              'beveragePairing',
              'estimatedCalories',
              'macros',
            ],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return { success: true, data: parsed };
    }
  } catch (err) {
    console.warn('Gemini API call failed, using intelligent culinary fallback:', err);
  }

  // Intelligent fallback if Gemini key is not configured
  return fallbackCraftPizza(userPrompt, inv);
}

function fallbackCraftPizza(prompt: string, inv: ReturnType<typeof getInventorySummary>) {
  const p = prompt.toLowerCase();

  let base = inv.bases[0]?.id || 'base-classic';
  let sauce = inv.sauces[0]?.id || 'sauce-san-marzano';
  let cheese = inv.cheeses[0]?.id || 'cheese-mozzarella';
  let vegs = ['veg-tomatoes', 'veg-spinach'];
  let name = 'La Sinfonia Napoletana';
  let tagline = 'Balanced Stone-Hearth Artisan Elegance';
  let tastingNotes = 'Lively San Marzano acidity dancing with creamy Fior di Latte and tender garden greens.';
  let beverage = 'Chilled Chianti Classico or sparkling San Pellegrino';

  if (p.includes('spicy') || p.includes('hot') || p.includes('fire')) {
    base = inv.bases.find((b) => b.id.includes('thin'))?.id || base;
    sauce = inv.sauces.find((s) => s.id.includes('arrabbiata') || s.id.includes('spicy'))?.id || sauce;
    cheese = inv.cheeses.find((c) => c.id.includes('cheddar') || c.id.includes('pepper'))?.id || cheese;
    vegs = ['veg-jalapenos', 'veg-bell-peppers', 'veg-onions'];
    name = 'Il Fuoco Calabrese';
    tagline = 'Fiery Zest with Golden Crisp Crunch';
    tastingNotes = 'Smoky Calabrian heat softened by rich melted cheese and sweet charred peppers.';
    beverage = 'Hoppy West Coast IPA or Iced Blood Orange Soda';
  } else if (p.includes('sweet') || p.includes('bbq') || p.includes('smok')) {
    base = inv.bases.find((b) => b.id.includes('burst') || b.id.includes('classic'))?.id || base;
    sauce = inv.sauces.find((s) => s.id.includes('bbq'))?.id || sauce;
    cheese = inv.cheeses.find((c) => c.id.includes('gouda'))?.id || cheese;
    vegs = ['veg-corn', 'veg-onions', 'veg-bell-peppers'];
    name = 'Rustico Affumicato';
    tagline = 'Sweet Chipotle Glaze with Applewood Smoke';
    tastingNotes = 'Deep caramelized sweetness balanced with applewood hazelnut notes and sweet corn bursts.';
    beverage = 'Crisp Dry Cider or Dark Amber Lager';
  } else if (p.includes('healthy') || p.includes('vegan') || p.includes('veg') || p.includes('green')) {
    base = inv.bases.find((b) => b.id.includes('multigrain') || b.id.includes('cauliflower'))?.id || base;
    sauce = inv.sauces.find((s) => s.id.includes('pesto'))?.id || sauce;
    cheese = inv.cheeses.find((c) => c.id.includes('vegan') || c.id.includes('burrata'))?.id || cheese;
    vegs = ['veg-spinach', 'veg-mushrooms', 'veg-tomatoes', 'veg-olives'];
    name = 'Il Bosco Verde';
    tagline = 'Farm-Fresh Harvest with Basil Aromas';
    tastingNotes = 'Herbaceous sweet basil aroma with earthy pan-roasted cremini mushrooms and ripe tomatoes.';
    beverage = 'Sauvignon Blanc or Lemon Basil Soda';
  } else if (p.includes('rich') || p.includes('truffle') || p.includes('cheese') || p.includes('creamy')) {
    base = inv.bases.find((b) => b.id.includes('burst'))?.id || base;
    sauce = inv.sauces.find((s) => s.id.includes('alfredo'))?.id || sauce;
    cheese = inv.cheeses.find((c) => c.id.includes('burrata') || c.id.includes('mozzarella'))?.id || cheese;
    vegs = ['veg-mushrooms', 'veg-spinach'];
    name = 'Quattro Velluto Oro';
    tagline = 'Velvety Garlic Cream & Silk Burrata';
    tastingNotes = 'Ultra-luxurious mouthfeel with confit garlic undertones and roasted mushroom umami.';
    beverage = 'Oak-Aged Chardonnay or Belgian Blonde Ale';
  }

  return {
    success: true,
    data: {
      name,
      tagline,
      description: `Crafted specifically for "${prompt}": Hand-stretched dough hearth-baked to blistered perfection.`,
      baseId: base,
      sauceId: sauce,
      cheeseId: cheese,
      vegetableIds: vegs,
      flavorHarmonyScore: 94,
      tastingNotes,
      beveragePairing: beverage,
      estimatedCalories: 260,
      macros: {
        proteinGrams: 14,
        carbsGrams: 32,
        fatsGrams: 11,
      },
    },
  };
}

// 2. AI Flavor Sommelier Analysis
export async function aiAnalyzeFlavor(config: {
  baseName: string;
  sauceName: string;
  cheeseName: string;
  vegetableNames: string[];
}) {
  const { baseName, sauceName, cheeseName, vegetableNames } = config;

  const systemInstruction = `
You are a master Italian culinary sommelier. Analyze this pizza recipe:
- Base Crust: ${baseName}
- Sauce: ${sauceName}
- Cheese: ${cheeseName}
- Toppings: ${vegetableNames.join(', ') || 'Cheese only'}

Provide an objective culinary evaluation of flavor balance, umami synergy, texture, and beverage pairing.
Return strictly valid JSON.
`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await geminiClient.models.generateContent({
        model: GEMINI_MODEL,
        contents: `Evaluate pizza harmony and wine/beverage pairing for this configuration.`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              harmonyScore: { type: Type.INTEGER, description: 'Score between 75 and 99' },
              harmonyGrade: { type: Type.STRING, description: 'e.g. Masterpiece, Excellent, Adventurous, Bold' },
              flavorProfile: { type: Type.STRING, description: 'Dominant notes e.g. Earthy, Tangy, Umami-rich, Herbal' },
              sommelierNote: { type: Type.STRING, description: '30-40 word professional tasting verdict' },
              pairingRecommendation: { type: Type.STRING, description: 'Best drink or wine pairing' },
              suggestedAddon: { type: Type.STRING, description: 'One ingredient that would elevate this further' },
              estimatedPerSliceCalories: { type: Type.INTEGER },
              macros: {
                type: Type.OBJECT,
                properties: {
                  proteinGrams: { type: Type.INTEGER },
                  carbsGrams: { type: Type.INTEGER },
                  fatsGrams: { type: Type.INTEGER },
                },
                required: ['proteinGrams', 'carbsGrams', 'fatsGrams'],
              },
            },
            required: [
              'harmonyScore',
              'harmonyGrade',
              'flavorProfile',
              'sommelierNote',
              'pairingRecommendation',
              'suggestedAddon',
              'estimatedPerSliceCalories',
              'macros',
            ],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return { success: true, analysis: parsed };
    }
  } catch (err) {
    console.warn('Gemini flavor analysis error, fallback triggered:', err);
  }

  // Heuristic calculation
  let score = 88;
  if (sauceName.includes('San Marzano') && cheeseName.includes('Mozzarella')) score += 7;
  if (sauceName.includes('Pesto') && vegetableNames.includes('Sun-Dried Roma Tomatoes')) score += 5;
  if (sauceName.includes('Alfredo') && vegetableNames.includes('Sautéed Cremini Mushrooms')) score += 4;
  score = Math.min(99, Math.max(78, score));

  return {
    success: true,
    analysis: {
      harmonyScore: score,
      harmonyGrade: score >= 95 ? 'Masterpiece D.O.P.' : score >= 88 ? 'Exemplary Balance' : 'Adventurous Fusion',
      flavorProfile: `${sauceName.includes('San Marzano') ? 'Tangy ' : ''}${cheeseName.includes('Gouda') ? 'Smoky ' : ''}Rich & Savory`,
      sommelierNote: `The ${baseName} provides a crisp golden foundation allowing the ${sauceName} and melted ${cheeseName} to emulsify smoothly with farm vegetables.`,
      pairingRecommendation: sauceName.includes('San Marzano')
        ? 'Chianti Classico DOCG or Italian San Pellegrino Aranciata'
        : sauceName.includes('Alfredo')
        ? 'Cold Chardonnay or Craft Pilsner'
        : 'Crisp Peroni Nastro Azzurro or Sparkling Water with Lime',
      suggestedAddon: vegetableNames.includes('Caramelized Red Onions') ? 'Sun-Dried Roma Tomatoes' : 'Caramelized Red Onions',
      estimatedPerSliceCalories: 245 + vegetableNames.length * 15,
      macros: {
        proteinGrams: 12 + Math.floor(vegetableNames.length * 1.5),
        carbsGrams: 30,
        fatsGrams: 9,
      },
    },
  };
}

// 3. AI Pizza Chef Luigi Assistant / Chat Copilot
export async function aiChatLuigi(messages: Array<{ role: 'user' | 'assistant'; content: string }>) {
  const inv = getInventorySummary();

  const systemInstruction = `
You are Maestro Luigi, an enthusiastic, friendly 3rd-generation Neapolitan master chef at PizzaCraft Pizzeria.
You speak with warmth, culinary passion, and occasional Italian flair ("Magnifico!", "Mamma Mia!", "Buon appetito!").
You know everything about PizzaCraft's menu, ingredients, dough fermentation (48-hour cold rise), stone hearth ovens (800°F), allergens, dietary choices (gluten-free, vegan, keto), and pairing.

Here is our live inventory & pantry:
Bases: ${inv.bases.map((b) => `${b.name} ($${b.price}, stock: ${b.stock})`).join(', ')}
Sauces: ${inv.sauces.map((s) => `${s.name} ($${s.price})`).join(', ')}
Cheeses: ${inv.cheeses.map((c) => `${c.name} ($${c.price})`).join(', ')}
Vegetables: ${inv.vegetables.map((v) => `${v.name} ($${v.price})`).join(', ')}

Rules:
- Be concise (2 to 4 sentences max), friendly, and appetizing.
- When recommending a combination, specify exact ingredients from our pantry.
- Suggest fun actionable next steps (like "Try building this in the Builder!" or "Check out Margherita Bella in Menu!").
`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const contents = messages.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));

      const response = await geminiClient.models.generateContent({
        model: GEMINI_MODEL,
        contents,
        config: {
          systemInstruction,
          temperature: 0.8,
        },
      });

      return {
        success: true,
        reply: response.text || 'Magnifico! How else can Maestro Luigi assist your pizza journey today?',
      };
    }
  } catch (err) {
    console.warn('Chef Luigi chat error, using fallback:', err);
  }

  // Graceful rule-based fallback
  const lastMsg = (messages[messages.length - 1]?.content || '').toLowerCase();
  let reply = 'Mamma Mia! Chef Luigi recommends our stone-fired Classic Hand Tossed crust with San Marzano tomatoes and Fior di Latte mozzarella! Can I help you craft something special?';

  if (lastMsg.includes('vegan') || lastMsg.includes('dairy free')) {
    reply = 'Bellissimo! For a 100% plant-based masterpiece, choose our Whole Wheat crust, Genovese Basil Pesto, Plant-Based Almond Mozzarella, and load up on baby spinach and cremini mushrooms!';
  } else if (lastMsg.includes('gluten') || lastMsg.includes('celiac')) {
    reply = 'Perfezione! We offer our Gluten-Free Cauliflower Herb crust baked in dedicated trays to avoid flour cross-contact, paired with San Marzano herb sauce and fresh burrata!';
  } else if (lastMsg.includes('calorie') || lastMsg.includes('diet') || lastMsg.includes('light')) {
    reply = 'Looking for a light crunch? Try our Thin & Crispy Roman crust with San Marzano sauce, moderate Fior di Latte, bell peppers, and baby spinach—under 220 calories a slice!';
  } else if (lastMsg.includes('spicy') || lastMsg.includes('hot')) {
    reply = 'Ah, a lover of fire! Try the Fiery Arrabbiata Marinara sauce with Aged Sharp Cheddar, pickled jalapeños, and caramelized onions on our crisp crust!';
  }

  return { success: true, reply };
}

// 4. AI Kitchen Demand & Restocking Optimization (For Kitchen & Admin)
export async function aiKitchenInsights() {
  const items = db.inventory.find();
  const orders = db.orders.find();
  const lowStock = items.filter((i) => i.stock < i.threshold);
  const activeOrders = orders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled');

  const systemInstruction = `
You are the AI Kitchen Optimization Engine for PizzaCraft.
Analyze current active orders (${activeOrders.length} active), low stock count (${lowStock.length} items below 20 threshold), and overall inventory.
Produce operational insights for kitchen staff:
- dynamicPrepTimeEst (estimated minutes for new incoming order)
- ovenLoadStatus (e.g. Optimal, Heavy Rush, Peak Capacity)
- priorityRestockItem (which item needs replenishment first)
- recommendations (array of 3 smart operational tips)
Return strictly valid JSON.
`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await geminiClient.models.generateContent({
        model: GEMINI_MODEL,
        contents: `Analyze current kitchen state. Low stock items: ${lowStock.map((i) => `${i.name} (stock: ${i.stock})`).join(', ')}. Active orders: ${activeOrders.length}.`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              dynamicPrepTimeEst: { type: Type.INTEGER, description: 'Est minutes (15-45)' },
              ovenLoadStatus: { type: Type.STRING, description: 'Optimal, Busy Rush, High Load' },
              ovenUtilizationPct: { type: Type.INTEGER, description: 'Percentage 40-95' },
              priorityRestockItem: { type: Type.STRING },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['dynamicPrepTimeEst', 'ovenLoadStatus', 'ovenUtilizationPct', 'priorityRestockItem', 'recommendations'],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return { success: true, data: parsed };
    }
  } catch (err) {
    console.warn('AI Kitchen insights fallback:', err);
  }

  // Fallback calculations
  const utilization = Math.min(95, 45 + activeOrders.length * 10);
  return {
    success: true,
    data: {
      dynamicPrepTimeEst: 18 + activeOrders.length * 3,
      ovenLoadStatus: activeOrders.length > 3 ? 'Peak Evening Rush' : 'Smooth Optimal Load',
      ovenUtilizationPct: utilization,
      priorityRestockItem: lowStock[0]?.name || 'Fior di Latte Mozzarella',
      recommendations: [
        lowStock.length > 0
          ? `Urgent: Restock ${lowStock[0]?.name} (${lowStock[0]?.stock} remaining).`
          : 'Stock levels healthy across all 4 categories.',
        `Hearth temperature steady at 800°F. Estimated throughput is ~12 pies every 15 minutes.`,
        'Prep extra dough balls for evening peak hour demand curve.',
      ],
    },
  };
}
